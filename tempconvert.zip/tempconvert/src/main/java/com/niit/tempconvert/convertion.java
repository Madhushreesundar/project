package com.niit.tempconvert;

public class convertion {
public static double farenheitToCelcius(double farenheit)
{return(farenheit-32)*5/9;
	}

public static double CelciusToFarenheit(double Celcius)
{
	return(Celcius*9/5)+32;
}
}